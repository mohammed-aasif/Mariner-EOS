export class Photos
{
    albumId:number;
    id:number
    title:String;
    url:String;
    thumbnailUrl:String;
}