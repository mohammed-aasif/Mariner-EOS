export class Albums
{
    userId: number;
    id:number;
    title:String;
}