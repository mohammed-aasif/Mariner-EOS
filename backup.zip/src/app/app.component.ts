import { Component } from '@angular/core';

 


@Component({
  selector: 'app-root',
 // template:'<ejs-schedule [currentView]="setView" ></ejs-schedule>',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  // providers: [TimelineMonthService, ResizeService, DragAndDropService]
})
export class AppComponent {
  
   
}

